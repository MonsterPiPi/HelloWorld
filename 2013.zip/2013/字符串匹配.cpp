////����KMP
//#include<iostream>
//#include<vector>
//using namespace std;
//#define MAX 1000
//int knext[MAX] = { 0 };
//vector<int> ans;
//void kmp(char *str) {
//	int lim = strlen(str);
//	if (lim) {
//		int i = 0, j = -1;
//		knext[0] = -1;
//		while (i < lim) {
//			if (j == -1 || str[i] == str[j]) {
//				knext[++i] = ++j;
//			}
//			else {
//				j = knext[j];
//			}
//		}
//	}
//}
//
//void match(char *str, char *pattern) {
//	ans.clear();
//	kmp(pattern);
//	int lim = strlen(pattern);
//	for (int i = 0, j = 0;str[i] != '\0';) {
//		if (j == -1 || str[i] == pattern[j]) {
//			i++, j++;
//		}
//		else {
//			j = knext[j];
//		}
//		if (j == lim) {
//			ans.push_back(i - lim);
//			j = knext[j];
//		}
//	}
//}
//
//int main() {
//	char A[MAX], B[MAX];
//	int N;
//	scanf("%d", &N);
//	getchar();
//	while (N-- > 0) {
//		gets_s(A);
//		gets_s(B);
//		match(A, B);
//		for (int i = 0; i < ans.size(); i++) {
//			if (i) printf(" ");
//			printf("%d", ans[i]);
//		}
//		printf("\n");
//	}
//	return 0;
//}