//#include<iostream>
//#include<cmath>
//#include<map>
//#include<queue>
//using namespace std;
//#define MAX 100
//int grid[MAX + 1][MAX + 1] = { 0 };
//int wall[MAX + 1][MAX + 1] = { false };
//int dx[4] = { 0 ,1, 0, -1 };//��,��,��,��
//int dy[4] = { 1, 0, -1, 0 };
//struct Pos {
//	int x, y;
//	Pos() {};
//	Pos(int a, int b) :x(a), y(b) {};
//	bool valid() {
//		return x && x <= MAX && y && y <= MAX;
//	}
//	Pos turn(int i) {
//		return Pos(x + dx[i], y + dy[i]);
//	}
//	bool operator!= (const Pos &p) {
//		return x != p.x || y != p.y;
//	}
//	bool operator== (const Pos &p) {
//		return x == p.x && y == p.y;
//	}
//};
//map<int, Pos> mdict;
//Pos dest;
//bool isPrimer(int a) {//1��������
//	if (a == 1) return false;
//	int lim = sqrt(a);
//	for (int i = 2; i <= lim; i++) {
//		if (a % i == 0) return false;
//	}
//	return true;
//}
//void init(int N) {//����һ��N * N������
//	int val = N * N;
//	int i = 1, j = 1, x, y, idx = 0;
//	grid[i][j] = val--;
//	while (val) {
//		x = i + dx[idx]; y = j + dy[idx];
//		if (!x || !y || x > N || y > N || grid[x][y]) {
//			idx = (idx + 1) % 4;
//		}
//		grid[i += dx[idx]][j += dy[idx]] = val;
//		mdict[val] = Pos(i, j);
//		if (isPrimer(val)) 
//			wall[i][j] = true;
//		val--;
//	}
//}
//
//int bfs(Pos pos) {
//	bool visited[101][101] = { false };
//	int step = 0;
//	queue<Pos> Q;
//	Q.push(pos);
//	Pos p = pos, last = pos, t = pos, lim = pos;
//	while (p != dest && !Q.empty()) {
//		p = Q.front(); Q.pop();
//		for (int i = 0; i < 4; i++) {
//			t = p.turn(i);
//			if (t.valid() && !visited[t.x][t.y] && !wall[t.x][t.y]) {
//				Q.push(t);
//				visited[t.x][t.y] = true;
//				last = t;
//			}
//		}
//		if (p == lim) {
//			if(lim != dest)step++;
//			lim = last;
//		}
//	}
//	return p == dest ? step : -1;
//}
//
//int main() {
//	init(MAX);
//	int N;
//	scanf("%d", &N);
//	for (int i = 1; i <= N; i++) {
//		int p, q;
//		scanf("%d %d", &p, &q);
//		dest = mdict[q];
//		printf("Case %d: ", i);
//		int ans = bfs(mdict[p]);
//		if (ans == -1) printf("Impossible\n");
//		else printf("%d\n", ans);
//	}
//	return 0;
//}