//#include<iostream>
//using namespace std;
//#define MAX 1000
//int main() {
//	char str[MAX], ans[MAX];
//	int K, idx = 0;
//	scanf("%s %d", str, &K);
//	for (int i = 0; str[i] != '\0'; i++) {
//		for (int j = 1; j <= K; j++) {
//			ans[idx++] = str[i];
//		}
//	}
//	ans[idx] = '\0';
//	printf("%s", ans);
//	return 0;
//}