//#include<iostream>
//using namespace std;
//#define MAX 1001
//class mPriorityQueue {
//public:
//	int front() {
//		if (lim > 1)
//			return A[1];
//		else
//			return -1;
//	}
//	void pop() {
//		if (lim == 1) printf("�����ѿ�\n");
//		int temp = A[1];
//		A[1] = A[lim - 1];
//		A[lim - 1] = temp;
//		lim--;
//		sift(1);
//	}
//	void init() {
//		FILE *fpin = freopen("2015_1_in.txt", "r", stdin);
//		FILE *fpout = freopen("2015_1_out.txt", "w", stdout);
//		for (int i = 1; i < MAX; i++) {
//			scanf("%d", &A[i]);
//		}
//		lim = MAX;
//		buildHeap();
//		for (int i = 1; i <= 300; i++) {
//			if (i > 1) printf(" ");
//			printf("%d", front());
//			pop();
//		}
//	}
//private:
//	int A[MAX] = { 0 };//�±��1��ʼ
//	int lim = 1;//�������һ��Ԫ�ص���һ��
//
//	void sift(int rt) {
//		for (int i = rt; i <= (lim - 1) >> 1;) {
//			int bigger = i << 1;
//			if (bigger + 1 < lim && A[bigger] < A[bigger + 1]) {//����Һ��Ӵ����Ҵ�������
//				bigger++;
//			}
//			if (A[i] < A[bigger]) {
//				int temp = A[bigger];
//				A[bigger] = A[i];
//				A[i] = temp;
//				i = bigger;
//			}
//			else
//				break;
//		}
//	}
//	void buildHeap() {
//		for (int i = (lim - 1) >> 1; i; i--) {
//			sift(i);
//		}
//	}
//};
//
//int main() {
//	mPriorityQueue m;
//	m.init();
//	return 0;
//}