//#include<iostream>
//using namespace std;
//int main() {
//	freopen("2015_1_in.txt", "w", stdout);
//	for (int i = 0; i < 1000; i++) {
//		if (i) printf(" ");
//		printf("%d", i);//���ڵ���
//	}
//	return 0;
//}