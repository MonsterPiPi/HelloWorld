#include<iostream>
#include<stack>
using namespace std;
#define MAX 1000
struct Node {
	int left, right;
}nodes[MAX];
bool isRoot[MAX];
int N;
void preOrder(int rt);
void inOrder(int rt);
void postOrder(int rt);

int main() {
	scanf("%d", &N);
	int F, L, R, rt;
	fill(isRoot, isRoot + MAX, true);
	for (int i = 0; i < N; i++) {
		scanf("%d %d %d", &F, &L, &R);
		nodes[F].left = L;
		nodes[F].right = R;
		if (L > -1) isRoot[L] = false;
		if (R > -1) isRoot[R] = false;
	}
	for (rt = 0; !isRoot[rt]; rt++);
	preOrder(rt);
	inOrder(rt);
	postOrder(rt);
	return 0;
}

void preOrder(int rt) {
	stack<int> S;
	int p = rt;
	while (p > -1 || !S.empty()) {
		if (p > -1) {//�����ǰָ��ǿգ� ѹ��ջ
			if (p != rt) printf(" ");
			printf("%d", p);
			S.push(p);
			p = nodes[p].left;
			
		}
		else {
			p = S.top();
			S.pop();
			p = nodes[p].right;
			
		}
	}
	printf("\n");
}

void inOrder(int rt) {
	stack<int> S;
	int p = rt;
	while (p > -1 || !S.empty()) {
		if (p > -1) {//�����ǰָ��ǿգ� ѹ��ջ
			S.push(p);
			p = nodes[p].left;

		}
		else {
			p = S.top();
			printf("%d", p);
			S.pop();
			p = nodes[p].right;
			if (p > -1 || !S.empty()) printf(" ");
		}
	}
	printf("\n");
}

void postOrder(int rt) {
	stack<int> S;
	int p = rt, last = -1;
	while (p > -1 || !S.empty()) {
		if (p > -1) {//�����ǰָ��ǿգ� ѹ��ջ
			S.push(p);
			p = nodes[p].left;
		}
		else {//
			p = S.top();
			if (nodes[p].right == -1 || nodes[p].right == last) {//����Ǵ��Һ��ӷ��ص�
				last = p;
				S.pop();
				printf("%d", p);
				if (!S.empty()) printf(" ");
				p = -1;
			}
			else {
				p = nodes[p].right;
			}
		}
	}
	printf("\n");
}
