//#include<iostream>
//using namespace std;
//int main() {
//	int N, A[10000], x;
//	scanf("%d", &N);
//	for (int i = 0; i < N; i++) scanf("%d", &A[i]);
//	scanf("%d", &x);
//	int sta = 0, end = N - 1, mid, ans =0;
//	while (sta <= end) {
//		mid = (sta + end) >> 1;
//		ans++;
//		if (A[mid] == x) {
//			printf("%d", ans);
//			return 0;
//		}
//		else if (A[mid] > x) {
//			end = mid;//Ӧ����mid - 1
//		}
//		else {
//			sta = mid;//Ӧ����mid + 1
//		}
//	}
//}
//����ò�ƶ���������